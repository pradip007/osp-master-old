angular.module('OSP', ['ngRoute','ngAnimate','loginModule','homeModule','adminModule','profileModule','ui.bootstrap.modal','ui.bootstrap','globalFactoryModule','ngStorage','ngResource','ngLoadingSpinner'])

    .run(function($rootScope,$location, $http, $timeout,$uibModal,$sessionStorage){
    
                        


 
           
 /* --- Included to change CONTEXT_URL as it will be changed during build ---*/
            $http.get('common/json/OSP_ServerUrlConfig.json').success(function(data,status,headers,config) {			
            CONTEXT_URL = data.URL.CONTEXT_URL;            
            console.log("success");
    
           
        }).error(function(data,status,headers,config){
             console.log('error');               
                
        });
      //  $http.defaults.headers.common.X-Auth-Token = "4iOUIU/DOY0fRQ05gXMGRcZizqNDxYpmfIhsDB7hAlI=";

       })

        .config(['$routeProvider','$httpProvider','$locationProvider','$sceDelegateProvider',function($routeProvider,$httpProvider,$locationProvider) {           
            
            delete $httpProvider.defaults.headers.common['X-Requested-With'];
              $httpProvider.defaults.useXDomain = true;
            
           
           // $httpProvider.defaults.withCredentials  = true;
            
            //$httpProvider.defaults.headers.common['X-Requested-With'];
         //  $logProvider.debugEnabled(true);

            $routeProvider
            
/* --------------------------------------  Login Module  ---------------------------------------------  */   
               
     $routeProvider.when('/login',{
        controller:'LoginController',
        templateUrl:'./app/login/templates/OSP_Login.html'
    })
     
/*--------------------------------------------------client module-------------------------------------*/
.when('/home',{
        controller: 'HomeController',
        templateUrl: './app/client/templates/OSP_home.html'
    })
/*--------------------------------------------------admin module-------------------------------------*/
.when('/adminmain',{
        controller: 'AdminMainController',
        templateUrl: './app/admin/templates/OSP_admin.html'
    })  
.when('/adminapproval',{
        controller: 'ApproveController',
        templateUrl: './app/admin/templates/OSP_approve.html'
    })
     
/*--------------------------------------------------professional module-------------------------------------*/     
.when('/addprofile',{
        controller: 'ProfAddController',
        templateUrl: 'app/professional/templates/OSP_ProfAdd.html'
    })
.when('/viewprofile',{
        controller: 'ProfViewController',
        templateUrl: 'app/professional/templates/OSP_ProfView.html'
    })
     
/* ------------ if none of the above states are matched, use this as the fallback  --------------------------  */
             
          .otherwise({redirectTo:'/login'});
           
}])
.directive('loading',   ['$http' ,function ($http)
    {
        return {
            restrict: 'A',
            link: function (scope, elm, attrs)
            {
                scope.isLoading = function () {
                    return $http.pendingRequests.length > 0;
                };

                scope.$watch(scope.isLoading, function (v)
                {
                    if(v){
                        elm.show();
                    }else{
                        elm.hide();
                    }
                });
            }
        };

    }]);

        