angular.module('adminFactoryModule', ['ngRoute'])
    .factory('AdminFactory', ["$http", function($http) {


        function approveService(profile, status) {
            var url= CONTEXT_URL+APPROVE_BASE_URL;
            //var url = "common/json/approve.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "PUT",
                url: url,
                headers:{
                    'X_Auth_Token' : X_auth_token
                },
                data: {"profId": profile,
          	         "actionTaken":status
                      }
            })
            return httpObject;
        };
        
          function approvelistService() {
            var url= CONTEXT_URL+FetchAPPROVELIST_BASE_URL;
            //var url = "common/json/approvelist.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,
                headers: {
                    'X_Auth_Token' : X_auth_token
                }
                 })
            return httpObject;
        };
        


        
        return {
            approveService: approveService,
            approvelistService: approvelistService
        };
    }])