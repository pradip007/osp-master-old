angular.module('approve', ['ngRoute', 'ngAnimate', 'ui.bootstrap.modal', 'ui.bootstrap'])
    .controller('ApproveController', ["$scope", "$location", "$timeout", "$uibModal", "AdminFactory", "LoginFactory", "ValidationFactory", "ErrorCode", "$localStorage", "$sessionStorage", "$window", function($scope, $location, $timeout, $uibModal, AdminFactory, LoginFactory, ValidationFactory, ErrorCode, $localStorage, $sessionStorage, $window) {
        if (!($sessionStorage.loginUsername && $sessionStorage.loginPassword && $sessionStorage.logintoken)) {

            $location.path('/login');
        }
        $scope.User = $sessionStorage.loginUsername;
        X_auth_token = $sessionStorage.logintoken;
        USER_ID = $sessionStorage.ProfID

        $scope.getapprovelist = function() {
            AdminFactory.approvelistService().success(function(result, status, headers, config) {
                var response = result;

                if (response.responseCode == "000") {
                    $scope.approvelist = response.responseObj;
                }

                if (!$scope.approvelist || $scope.approvelist.length === 0) {
                    LoginFactory.setalert('No User is currently pending Approval', 'Failure');
                    callalert();
                    $scope.noApprovals = 'No User is currently pending Approval';
                } else {
                    $scope.noApprovals = false;
                    console.log($scope.approvelist);
                    for (var i = 0; i < $scope.approvelist.length; i++) {
                        var name = $scope.approvelist[i].profFirstName + ' ' + $scope.approvelist[i].profLastName;
                        $scope.approvelist[i].name = name;
                    }
                }

            }).error(function(data, status, headers, config) {
                if (status == 401) {
                    $scope.open();
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                    // $scope.noApprovals = 'Unable to connect to server . Please try again.';
                }
            });


        }

        $scope.getapprovelist();

        $scope.approve = function(profile, status) {
            AdminFactory.approveService(profile, status).success(function(result, status, headers, config) {
                if (result.responseCode == '000') {
                    $scope.notApproved = false;
                    LoginFactory.setalert(result.responseMsg, 'Success');
                    callalert();
                    // $scope.notApproved = result.responseMsg;
                    $scope.getapprovelist();
                } else {
                    LoginFactory.setalert(result.responseMsg, 'Failure');
                    callalert();
                    //$scope.notApproved = 'Not approved Please try again';
                }

            }).error(function(data, status, headers, config) {
                if (status == 401) {
                    $scope.open();
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                    //$scope.noApprovals = 'Unable to connect to server . Please try again.';
                }
            });
        };

        $scope.viewProfile = function(profid) {
            View_TYPE = 'ADMIN';
            PROFID = profid;
            $sessionStorage.viewProfID = PROFID;
            $location.path('/viewprofile');

        }




        /*----------login functionality -------------*/

        $scope.open = function() {

            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'loginmodal.html',
                controller: childloginController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
            modalInstance.result.then(function(login) {

                console.log('modal dismissed');
            }, function() {
                console.log('modal dismissed');

            });

        };


        var childloginController = function($scope, $location, $localStorage, $sessionStorage, $uibModalInstance) {



            $scope.login = {
                "username": '',
                "passWord": ''
            };
            $scope.userName = '';
            $scope.passWord = '';
            $scope.incorrect_login = false;

            if ($localStorage.loginUsername) {
                $scope.userName = $localStorage.loginUsername;
            }
            if ($localStorage.loginPassword) {
                $scope.passWord = $localStorage.loginPassword;
            }

            $scope.loginSubmit = function() {
                //$uibModalInstance.close({ my: 'data' });
                validateUsernamePassword();

            }


            $scope.cancel = function() {
                $uibModalInstance.dismiss('cancel');
            }


            validateUsernamePassword = function() {
                $scope.incorrect_login = false;
                if (ValidationFactory.hasSpecialCharacter($scope.userName)) {
                    $scope.incorrect_login = "Enter a valid username";
                    return false;
                } else {
                    $scope.login = {
                        "username": $scope.userName,
                        "passWord": $scope.passWord
                    };
                    //LoginFactory.encodePassword($scope.passWord)
                    $scope.callLoginService();
                }
            };


            $scope.callLoginService = function() {

                LoginFactory.loginService($scope.login).success(function(result, status, headers, config) {
                    //alert('success');

                    if (status = 200) {

                        USERNAME = $scope.login.username;
                        PASSWORD = $scope.login.passWord;
                        var resultHeaders = headers();
                        console.log(JSON.stringify(result));
                        console.log(JSON.stringify(status));
                        console.log(JSON.stringify(resultHeaders));
                        console.log(JSON.stringify(config));

                        USER_ID = resultHeaders.user_id;
                        X_auth_token = resultHeaders.x_auth_token;


                        $sessionStorage.loginUsername = $scope.login.username;
                        $sessionStorage.loginPassword = $scope.login.passWord;
                        $sessionStorage.logintoken = X_auth_token;
                        $sessionStorage.ProfID = USER_ID;
                        if ($scope.remember) {
                            $localStorage.loginUsername = $scope.login.username;
                            $localStorage.loginPassword = $scope.login.passWord;
                        }
                        $uibModalInstance.dismiss('cancel');

                    } else {
                        $scope.incorrect_login = "Invalid Username or Password";
                        return false;
                    }
                }).error(function(data, status, headers, config) {
                    if (status = 401) {
                        $scope.incorrect_login = "Invalid Username or Password";
                    } else {
                        $scope.incorrect_login = "Unable to connect to server . Please try again.";
                    }

                });
            };
        };
        /*----------login functionality -------------*/

        $scope.toggleAnimation = function() {
            $scope.animationsEnabled = !$scope.animationsEnabled;
        };


        /*----------alert functionality -------------*/
        callalert = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'alert.html',
                controller: childalertController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
        };
        var childalertController = function($scope, $uibModalInstance) {
                var alert = LoginFactory.getalert();
                $scope.alertHead = alert.head;
                $scope.alertText = alert.text;
                $scope.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                }

            }
            /*----------alert functionality -------------*/




    }]);


(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('ChildloginController', childloginController);

    childloginController.$inject = ['$controller'];

    function childloginController($controller) {
        var self = this;

        var baseController = $controller('ApproveController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();

(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('childalertController', childalertController);

    childalertController.$inject = ['$controller'];

    function childalertController($controller) {
        var self = this;

        var baseController = $controller('ApproveController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();