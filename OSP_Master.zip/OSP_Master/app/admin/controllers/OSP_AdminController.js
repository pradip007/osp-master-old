angular.module('adminMain', ['ngRoute', 'ngAnimate', 'ui.bootstrap.modal', 'ui.bootstrap'])
    .controller('AdminMainController', ["$scope", "$location", "$timeout", "LoginFactory", "$uibModal", "$window", "ValidationFactory", "ErrorCode","$localStorage","$sessionStorage", function($scope, $location, $timeout, LoginFactory, $uibModal, $window, ValidationFactory, ErrorCode,$localStorage, $sessionStorage) {
        
        if(!($sessionStorage.loginUsername && $sessionStorage.loginPassword && $sessionStorage.logintoken)){
            
             $location.path('/login');
        }
         $scope.User = $sessionStorage.loginUsername;
         X_auth_token = $sessionStorage.logintoken;
        USER_ID = $sessionStorage.ProfID 
    }]);