angular.module('homeFactoryModule', ['ngRoute'])
    .factory('HomeFactory', ["$http", function($http) {



    }])