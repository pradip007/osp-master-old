angular.module('home', ['ngRoute', 'ngAnimate', 'ui.bootstrap.modal', 'ui.bootstrap'])
    .controller('HomeController', ["$scope", "$location", "$timeout", "LoginFactory", "$uibModal", "$window", "ValidationFactory", "ErrorCode","$localStorage","$sessionStorage", function($scope, $location, $timeout, LoginFactory, $uibModal, $window, ValidationFactory, ErrorCode,$localStorage, $sessionStorage) {
        
        if(!($sessionStorage.loginUsername && $sessionStorage.loginPassword && $sessionStorage.logintoken)){
            
             $location.path('/login');
        }
        $scope.myInterval = 3000;
        $scope.slides = [{
            image: {
                "src": './assets/images/banner-img01.jpg',
                "show": true
            }
        }, {
            image: {
                "src": './assets/images/banner-img02.jpg',
                "show": false
            }
        }, {
            image: {
                "src": './assets/images/banner-img03.jpg',
                "show": false
            }
        }, ];
         $scope.User = $sessionStorage.loginUsername;
         X_auth_token = $sessionStorage.logintoken;
         USER_ID = $sessionStorage.ProfID 
                         
        
        

    }]);