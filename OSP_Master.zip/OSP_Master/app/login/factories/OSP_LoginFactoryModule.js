angular.module('loginFactoryModule', ['ngRoute'])
    .factory('LoginFactory', ["$http", function($http) {

        var alertText = '';
        var alertHead = '';

        function loginService(login) {
            var url = CONTEXT_URL + LOGIN_BASE_URL;
            //var url = "common/json/login.json";
            console.log("URL for LOGIN: " + url);
            //var encodePassword = encodePassword
            //'X_Authorization':  "Basic"+" "+encodePassword(login.username+":"+login.passWord)
            //var token =  "Basic"+" "+encodePassword(username+":"+password)

            var httpObject = $http({
                method: "POST",
                url: url,
                headers: {
                    'X_Authorization': "Basic" + " " + encodePassword(login.username + ":" + login.passWord)

                }

            })
            return httpObject;
        };

        function getUserdetails() {
            var url = CONTEXT_URL + USERDETAILS_URL + USER_ID;
            //var url = "common/json/login.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,
                headers: {
                    'X_Auth_Token': X_auth_token
                }

            })
            return httpObject;
        };

        function encodePassword(string) {

            var encodedPassword = Base64.encode(string);
            //  console.log("encoded pass: "+encodedPassword);
            return encodedPassword;
        };

        function forgetpassService(username, email) {
            var url = CONTEXT_URL + FP_BASE_URL;
            //var url = "common/json/FP.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "POST",
                url: url,
                headers: {
                    "Content-Type": "application/json"
                },
                data: {
                    'userName': username,
                    'email': email
                }


            })
            return httpObject;
        };

        function checkuserService(username) {
            var url = CONTEXT_URL + CHECKUSER_BASE_URL + username;
            //var url = "common/json/check_user.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,
                headers: {
                    "Content-Type": "application/json"
                },
                data: ''


            })
            return httpObject;
        };

        function signupService(singupObject) {
            var url = CONTEXT_URL + SIGNUP_BASE_URL;
            //var url = "common/json/signup.json";
            console.log("URL for LOGIN: " + url);

            if (!singupObject.encryptedProf_id) {
                var dataforReq = {
                    "userName": singupObject.username,
                    "password": singupObject.password,
                    "userContact": singupObject.phone,
                    "email": singupObject.email,
                    "firstName": singupObject.firstname,
                    "confirmPassword": singupObject.password,
                    "lastName": singupObject.lastname
                };
            } else {
                dataforReq = {
                    "userName": singupObject.username,
                    "password": singupObject.password,
                    "userContact": singupObject.phone,
                    "email": singupObject.email,
                    "firstName": singupObject.firstname,
                    "confirmPassword": singupObject.password,
                    "lastName": singupObject.lastname,
                    "encryptedProf_id": singupObject.encryptedProf_id
                }
            }
            var httpObject = $http({
                method: "POST",
                url: url,
                data: dataforReq

            })
            return httpObject;
        };

        function getviewProfdetails(hiddentoken) {
            var url = CONTEXT_URL + TOKEN_URL + hiddentoken;
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url

            })
            return httpObject;
        };

        function setalert(text, head) {
            alertText = text;
            alertHead = head
        }

        function getalert() {
            var alert = {
                'text': alertText,
                'head': alertHead
            };
            return alert;
        }

        return {
            forgetpassService: forgetpassService,
            encodePassword: encodePassword,
            loginService: loginService,
            checkuserService: checkuserService,
            signupService: signupService,
            getUserdetails: getUserdetails,
            setalert: setalert,
            getalert: getalert
        };

    }])