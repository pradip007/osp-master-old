angular.module('login', ['ngRoute', 'ngAnimate', 'ui.bootstrap.modal', 'ui.bootstrap'])
    .controller('LoginController', ["$scope", "$location", "$timeout", "LoginFactory", "$uibModal", "$window", "ValidationFactory", "ErrorCode", "$localStorage", "$sessionStorage", function($scope, $location, $timeout, LoginFactory, $uibModal, $window, ValidationFactory, ErrorCode, $localStorage, $sessionStorage) {

        $scope.animationsEnabled = true;
        $scope.remember = false;
        
                        $scope.$watchGroup(['spinnerActive'], function() {
                         console.log('hoho');
                         if($scope.spinnerActive){
                            window.blur();
                         }
                         else{
                            window.focus();
                         }
                });

        

        $sessionStorage.loginUsername = undefined;
        $sessionStorage.loginPassword = undefined;
        $sessionStorage.logintoken = undefined;
        $sessionStorage.ProfID = undefined;
        $sessionStorage.viewProfID = undefined;
        PROFID = '';
        View_TYPE = '';

        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        };

        if ((window.location.href.indexOf("http") > -1)) {
            var hiddentoken = getParameterByName('tokenid');
        }

        if (hiddentoken) {
            LoginFactory.getviewProfdetails(hiddentoken).success(function(result, status, headers, config) {

                if (result.responseCode == 000) {

                    $sessionStorage.signupfrstName = result.responseObj.profFirstName;
                    $sessionStorage.signupLastName = result.responseObj.profLastName;
                    $sessionStorage.signupEmail = result.responseObj.contactList[0].contactEmail;
                    callopensignupModal();


                } else {


                    $scope.incorrect_username = result.responseMsg;
                    return false;
                }

            }).error(function(data, status, headers, config) {
                $scope.incorrect_username = 'Failed to fetch details';
                return false;
            });

        }

        callopenloginModal = function() {
            $scope.open();
        };

        $scope.myInterval = 3000;
        $scope.slides = [{
            image: {
                "src": './assets/images/banner-img01.jpg',
                "show": true
            }
        }, {
            image: {
                "src": './assets/images/banner-img02.jpg',
                "show": false
            }
        }, {
            image: {
                "src": './assets/images/banner-img03.jpg',
                "show": false
            }
        }, ];




        /*---------signup functionality-------------*/

        callopensignupModal = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'registration.html',
                controller: childsignupController,
                size: '',
                windowClass: 'app-modal-window',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });

            modalInstance.result.then(function(login) {
                console.log('modal dismissed');
            }, function() {
                console.log('modal dismissed');

            });
        };
        //$uibModalInstance.close({ my: 'data' });
        var childsignupController = function($scope, $uibModalInstance, $sessionStorage) {

                $scope.$watchGroup(['firstName', 'lastName', 'signEmail', 'signuserName', 'signPassword', 'contactNumber', 'confirmPassword', 'terms'], function() {
                    $scope.incorrect_username = false;
                    $scope.correct_username = false;
                });


                var singupObject = {
                    'username': '',
                    'password': '',
                    'phone': '',
                    'firstname': '',
                    'lastname': '',
                    'email': '',
                    'encryptedProf_id': hiddentoken
                };

                $scope.firstName = '';
                $scope.lastName = '';
                $scope.signuserName = '';
                $scope.signEmail = '';
                $scope.contactNumber = '';
                $scope.signPassword = '';
                $scope.confirmPassword = '';
                $scope.pincode = '';

                if ($sessionStorage.signupfrstName) {
                    $scope.firstName = $sessionStorage.signupfrstName;
                }

                if ($sessionStorage.signupLastName) {
                    $scope.lastName = $sessionStorage.signupLastName;
                }

                if ($sessionStorage.signupEmail) {
                    $scope.signEmail = $sessionStorage.signupEmail;
                }



                $scope.incorrect_username = false;
                $scope.correct_username = false;

                $scope.username_check = false;
                $scope.username_check_failed = false;

                $scope.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                }

                $scope.checkusername = function() {

                    if (!ValidationFactory.hasSpecialCharacter($scope.signuserName)) {
                        $scope.username_check = true;
                        $scope.incorrect_username = false;
                        $scope.correct_username = false;

                        LoginFactory.checkuserService($scope.signuserName).success(function(result, status, headers, config) {
                            //alert('success');
                            $scope.username_check = false;
                            if (result.responseCode == '000') {
                                $scope.correct_username = true;
                                $scope.correct_username = 'Username Available';
                                $scope.username_check_failed = true;
                                return false;
                            } else {
                                $scope.username_check_failed = false;
                                $scope.incorrect_username = "Username not Available";
                                return false;
                            }

                        }).error(function(data, status, headers, config) {
                            $scope.username_check = false;
                            $scope.username_check_failed = false;
                            $scope.incorrect_username = 'user name not verified';
                        });
                    } else {
                        $scope.incorrect_username = "Enter a valid username";
                        $scope.correct_username = false;
                        return false;
                    }
                }

                $scope.signUpSubmit = function() {
                    $scope.correct_username = false;

                    if (ValidationFactory.hasSpecialCharacter($scope.signuserName)) {
                        $scope.incorrect_username = "Enter a valid username";
                        return false;
                    } else if (ValidationFactory.isAplhabetic($scope.firstName) || ValidationFactory.isAplhabetic($scope.lastName)) {
                        $scope.incorrect_username = "Name must be aplhabetical";
                        return false;
                    }

                    $scope.correct_username = false;

                    if (!$scope.signuserName) {
                        $scope.incorrect_username = "Please enter a username";
                        return false;
                    }

                    if (!$scope.username_check_failed) {
                        $scope.incorrect_username = "Please enter a valid username";
                        return false;
                    }
                    if (ValidationFactory.notemail($scope.signEmail)) {
                        $scope.incorrect_username = "Please enter a valid email";
                        return false;
                    }

                    if (ValidationFactory.notaNumer($scope.contactNumber) || $scope.contactNumber.length != 10) {
                        $scope.incorrect_username = "Please enter a correct Phone number";
                        return false;
                    } else if ($scope.signPassword != $scope.confirmPassword) {
                        $scope.incorrect_username = "Confirm Password does not match original one";
                        return false;
                    } else if (!$scope.terms) {
                        $scope.incorrect_username = "Please agree to the terms and conditions";
                        return false;
                    } else {
                        //$scope.signPassword = LoginFactory.encodePassword($scope.signPassword);
                        var singupObject = {
                            'username': $scope.signuserName,
                            'password': $scope.signPassword,
                            'phone': $scope.contactNumber,
                            'firstname': $scope.firstName,
                            'lastname': $scope.lastName,
                            'email': $scope.signEmail
                        };

                        LoginFactory.signupService(singupObject).success(function(result, status, headers, config) {
                            // alert('success');
                            $scope.username_check = false;
                            $scope.incorrect_username = false;
                            $scope.correct_username = false;
                            console.log(JSON.stringify(result));

                            if (result.responseCode == 000) {
                                console.log($scope.correct_username);
                                LoginFactory.setalert(result.responseObj.returnMessage, 'Success');
                                $uibModalInstance.dismiss('cancel');
                                callalert();
                                //$scope.correct_username = result.responseObj.returnMessage;
                                //console.log($scope.correct_username);
                                return;
                            } else {
                                //LoginFactory.setalert(result.responseMsg, 'Failure');
                                //$uibModalInstance.dismiss('cancel');
                                //callalert()
                                $scope.incorrect_username = result.responseMsg;
                                return false;
                            }

                        }).error(function(data, status, headers, config) {
                            $scope.incorrect_username = 'Failed to connect to server, Please try Again.';
                            return false;
                        });

                    }
                }

            }
            /*---------signup functionality-------------*/




        /*----------alert functionality -------------*/
        callalert = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'alert.html',
                controller: childalertController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
        };
        var childalertController = function($scope, $uibModalInstance) {
                var alert = LoginFactory.getalert();
                $scope.alertHead = alert.head;
                $scope.alertText = alert.text;
                $scope.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                }

            }
            /*----------alert functionality -------------*/




        /*----------forgetpass functionality -------------*/

        callopenForgetModal = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'forgetpassword.html',
                controller: childforgetpassController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });

            modalInstance.result.then(function(login) {
                console.log('modal dismissed');
            }, function() {
                console.log('modal dismissed');

            });
        };
        var childforgetpassController = function($scope, $uibModalInstance) {

            $scope.$watchGroup(['FP_username', 'FP_email'], function() {
                $scope.incorrect_fp = false;
                $scope.correct_fp = false;
            });

            $scope.FP_username = '';
            $scope.FP_email = '';



            $scope.incorrect_fp = false;
            $scope.correct_fp = false;

            $scope.openloginModal = function() {
                $uibModalInstance.dismiss('cancel');
                callopensignupModal();
            };
            $scope.fpSubmit = function() {
                $scope.incorrect_fp = false;
                $scope.correct_fp = false;
                callemailservice();
            };
            $scope.cancel = function() {
                $uibModalInstance.dismiss('cancel');
            }
            callemailservice = function() {

                if (ValidationFactory.hasSpecialCharacter($scope.FP_username)) {
                    $scope.incorrect_fp = "Enter a valid username";
                    return false;
                }
                if (ValidationFactory.notemail($scope.FP_email)) {
                    $scope.incorrect_fp = "Please enter a valid email";
                    return false;
                } else {

                    LoginFactory.forgetpassService($scope.FP_username, $scope.FP_email).success(function(result, status, headers, config) {
                        //alert('success');
                        if (result.responseCode == 000) {
                            LoginFactory.setalert(result.responseObj.returnMessage, 'Success');
                            $uibModalInstance.dismiss('cancel');
                            callalert();
                            //$scope.correct_fp = result.responseObj.returnMessage;
                            return;
                        } else {
                            //LoginFactory.setalert(result.responseMsg, 'Failure');
                            //$uibModalInstance.dismiss('cancel');
                            //callalert();
                            $scope.incorrect_fp = result.responseMsg;
                            return false;
                        }

                    }).error(function(data, status, headers, config) {
                        console.log('error');
                    });
                }
            }
        }

        /*----------forgetpass functionality -------------*/




        /*----------login functionality -------------*/

        $scope.open = function() {

            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'loginmodal.html',
                controller: childloginController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
            modalInstance.result.then(function(login) {

                console.log('modal dismissed');
            }, function() {
                console.log('modal dismissed');

            });

        };


        var childloginController = function($scope, $uibModalInstance, $location, $localStorage, $sessionStorage) {

            $scope.$watchGroup(['userName', 'passWord'], function() {
                $scope.incorrect_login = false;
               
            });

            $scope.login = {
                "username": '',
                "passWord": ''
            };
            $scope.userName = '';
            $scope.passWord = '';
            $scope.incorrect_login = false;

            if ($localStorage.loginUsername) {
                $scope.userName = $localStorage.loginUsername;
            }
            if ($localStorage.loginPassword) {
                $scope.passWord = $localStorage.loginPassword;
            }

            $scope.loginSubmit = function() {
                //$uibModalInstance.close({ my: 'data' });
                validateUsernamePassword();

            }
            $scope.openForgetModal = function() {
                $uibModalInstance.dismiss('cancel');
                callopenForgetModal();
            }
            $scope.opensignupModal = function() {
                $uibModalInstance.dismiss('cancel');
                // $uibModalInstance.close({ my: 'data' });
                callopensignupModal();
            }

            $scope.cancel = function() {
                $uibModalInstance.dismiss('cancel');
            }


            validateUsernamePassword = function() {
                $scope.incorrect_login = false;
                if (ValidationFactory.hasSpecialCharacter($scope.userName)) {
                    $scope.incorrect_login = "Enter a valid username";
                    return false;
                } else {
                    $scope.login = {
                        "username": $scope.userName,
                        "passWord": $scope.passWord
                    };
                    //LoginFactory.encodePassword($scope.passWord)
                    $scope.callLoginService();
                }
            };


            $scope.callLoginService = function() {

                LoginFactory.loginService($scope.login).success(function(result, status, headers, config) {
                    // alert('success');

                    if (status = 200) {

                        USERNAME = $scope.login.username;
                        PASSWORD = $scope.login.passWord;
                        var resultHeaders = headers();
                        //var abc = config.transformResponse[0];
                        //console.log(abc);  
                        //alert(abc);            
                        console.log(JSON.stringify(result));
                        console.log(JSON.stringify(status));
                        console.log(JSON.stringify(resultHeaders));
                        console.log(JSON.stringify(config));

                        USER_ID = resultHeaders.user_id;
                        X_auth_token = resultHeaders.x_auth_token;
                        LoginFactory.getUserdetails().success(function(result, status, headers, config) {


                            PROFID = '';
                            if (result.responseCode == '000') {
                            $uibModalInstance.close($scope.login);
                            //$localStorage.LocalMessage = "LocalStorage: My name is Mudassar Khan.";
                            $sessionStorage.loginUsername = $scope.login.username;
                            $sessionStorage.loginPassword = $scope.login.passWord;
                            $sessionStorage.logintoken = X_auth_token;
                            $sessionStorage.ProfID = USER_ID;
                            if ($scope.remember) {
                                $localStorage.loginUsername = $scope.login.username;
                                $localStorage.loginPassword = $scope.login.passWord;
                            }
                                
                                if (result.responseObj.returnMessage == 'ADMIN' && result.responseObj.typeId == '50') {
                                    $location.path('/adminmain');
                                } else if (result.responseObj.returnMessage == "view" && result.responseObj.typeId == '23') {
                                    $location.path('/viewprofile');
                                } else if (result.responseObj.returnMessage == "add" && result.responseObj.typeId == '23') {
                                    $location.path('/addprofile');
                                } else {
                                    $location.path('/home');
                                }
                            } else {
                                //LoginFactory.setalert(result.responseMsg, 'Failure');
                                // $uibModalInstance.dismiss('cancel');
                                // callalert();
                                $scope.incorrect_login = result.responseMsg;
                                return false;
                            }
                        }).error(function(data, status, headers, config) {
                            $scope.incorrect_login = "Unable to connect to server . Please try again.";
                            console.log('error');
                        });


                    } else {
                        $scope.incorrect_login = "Invalid Username or Password";
                        return false;
                    }
                }).error(function(data, status, headers, config) {
                    if (status = 401) {
                        $scope.incorrect_login = "Invalid Username or Password";
                    } else {
                        $scope.incorrect_login = "Unable to connect to server . Please try again.";
                    }

                });
            };
        };
        /*----------login functionality -------------*/

        $scope.toggleAnimation = function() {
            $scope.animationsEnabled = !$scope.animationsEnabled;
        };



    }]);




(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('ChildloginController', childloginController);

    childloginController.$inject = ['$controller'];

    function childloginController($controller) {
        var self = this;

        var baseController = $controller('LoginController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();




(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('ChildforgetpassController', childforgetpassController);

    childforgetpassController.$inject = ['$controller'];

    function childforgetpassController($controller) {
        var self = this;

        var baseController = $controller('LoginController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();




(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('ChildsignupController', childsignupController);

    childsignupController.$inject = ['$controller'];

    function childsignupController($controller) {
        var self = this;

        var baseController = $controller('LoginController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();

(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('childalertController', childalertController);

    childalertController.$inject = ['$controller'];

    function childalertController($controller) {
        var self = this;

        var baseController = $controller('LoginController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();