angular.module('profFactoryModule', ['ngRoute'])
    .factory('ProfileFactory', ["$http", function($http) {


        function getUserdetails() {
            if(View_TYPE == 'ADMIN'){
                var url= CONTEXT_URL+getUserdetailsURL+PROFID;
            }
            else{
                var url= CONTEXT_URL+getUserdetailsURL+USER_ID;
            }
           // var url = "common/json/login.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,

            })
            return httpObject;
        };

     function getaddProfdetails() {
            var url= CONTEXT_URL+getProfDetailsURL;
            //var url = "common/json/addprofdata.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,
                headers: {
                    'X_Auth_Token' : X_auth_token
                    
                }

            })
            return httpObject;
        };
        
        function getviewProfdetails(profid) {
            if(profid){
            var url= CONTEXT_URL+ViewAdminPROF_URL+profid;
            }
            else{
                var url= CONTEXT_URL+ViewPROF_URL;
            }
           // var url = "common/json/view.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,
                headers: {
                    'X_Auth_Token' : X_auth_token
                    
                }

            })
            return httpObject;
        };
        
        
function saveProfile(pramas,user) {
            var url= CONTEXT_URL+SAVEPROF_URL;
            //var url = "common/json/addprofdata.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "POST",
                url: url,
                headers: {
                    'X_Auth_Token' : X_auth_token
                },
                data: pramas

            })
            return httpObject;
        };        

function getDistdetails(state) {
            var url= CONTEXT_URL+getDistdetailsURL+state;
            //var url = "common/json/addprofdata.json";
            console.log("URL for LOGIN: " + url);

            var httpObject = $http({
                method: "GET",
                url: url,
                headers: {
                    'X_Auth_Token' : X_auth_token
                }

            })
            return httpObject;
        };
        
function changedate(input){
    input = input.toString();
    var year = input.substr(11,4),
    month = ['Jan','Feb','Mar','Apr','May','Jun',
             'Jul','Aug','Sep','Oct','Nov','Dec'].indexOf(input.substr(4,3))+1,
    day = input.substr(8,2);

var output =  day + '/' + (month<10?'0':'') + month + '/' +  year;
        return output;
};

        function encodePassword(string) {

            var encodedPassword = Base64.encode(string);
            //  console.log("encoded pass: "+encodedPassword);
            return encodedPassword;
        };

        return {
           getUserdetails : getUserdetails,
           getaddProfdetails : getaddProfdetails,
            getDistdetails:getDistdetails,
            changedate:changedate,
            saveProfile:saveProfile,
            getviewProfdetails:getviewProfdetails,
            encodePassword:encodePassword
            
        };

    }])