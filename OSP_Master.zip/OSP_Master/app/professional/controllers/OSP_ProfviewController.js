angular.module('profView', ['ngRoute', 'ngAnimate', 'ui.bootstrap.modal', 'ui.bootstrap'])
    .controller('ProfViewController', ["$scope", "$location", "$timeout", "$uibModal", "ValidationFactory", "ProfileFactory", "LoginFactory", "$window", "ErrorCode", "$localStorage", "$sessionStorage", function($scope, $location, $timeout, $uibModal, ValidationFactory, ProfileFactory, LoginFactory, $window, ErrorCode, $localStorage, $sessionStorage)  {

        if (!($sessionStorage.loginUsername && $sessionStorage.loginPassword && $sessionStorage.logintoken)) {

            $location.path('/login');
        }
        $scope.User = $sessionStorage.loginUsername;
        X_auth_token = $sessionStorage.logintoken;
        USER_ID = $sessionStorage.ProfID;
        PROFID = $sessionStorage.viewProfID;


        callgetAddprofdetails = function() {

            ProfileFactory.getaddProfdetails().success(function(result, status, headers, config) {
                //alert('success');
                if (result.responseObj.genders && result.responseObj.genders.length != 0) {
                    $scope.genderlist = result.responseObj.genders;
                } else {

                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }

                if (result.responseObj.maritalStatus && result.responseObj.maritalStatus.length != 0) {
                    $scope.marriedstatusList = result.responseObj.maritalStatus;
                } else {

                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                if (result.responseObj.locations && result.responseObj.locations.length != 0) {
                    $scope.nationalitylist = result.responseObj.locations;
                    //$scope.statelist = $scope.nationalitylist[0].childLocations;
                } else {

                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                if (result.responseObj.categories && result.responseObj.categories.length != 0) {
                    $scope.catagorylist = result.responseObj.categories;
                } else {

                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                callgetviewDeatils();

            }).error(function(data, status, headers, config) {
                if (status == 401) {
                       $scope.open();	
                } else {

                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                
            });

        };
        callgetAddprofdetails();


        callgetviewDeatils = function() {



            ProfileFactory.getviewProfdetails(PROFID).success(function(result, status, headers, config) {
                //alert('success');
                if (result.responseCode == 000 && result.responseStatus == 'success') {
                    $scope.details = result;
                    callSetuserdetails();
                }
            }).error(function(data, status, headers, config) {
                if (status == 401) {
                       $scope.open();	
                } else {

                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                
            });




        };

        callSetuserdetails = function() {

            $scope.view = $scope.details.responseObj;



            $scope.profName = $scope.view.profFirstName + ' ' + $scope.view.profLastName;
            $scope.profDOB = $scope.view.profDob;
            $scope.profPhone = $scope.view.contactList[0].contactPhone;
            $scope.profEmail = $scope.view.contactList[0].contactEmail;
            //$scope.profNation  =  $scope.view.profNationality;
            $scope.profAddress = $scope.view.profAddressLocations[0];
            $scope.Area = $scope.profAddress.location.name;
            $scope.twn = $scope.profAddress.location.parent.name;
            $scope.dist = $scope.profAddress.location.parent.parent.name;
            $scope.state = $scope.profAddress.location.parent.parent.parent.name;
            $scope.profNation = $scope.profAddress.location.parent.parent.parent.parent.name;
            $scope.profaddr1 = $scope.profAddress.address.line1;
            $scope.profaddr2 = $scope.profAddress.address.line2;
            $scope.ProfPin = $scope.profAddress.address.pinCode;

            if ($scope.profaddr1 || $scope.profaddr2 || $scope.ProfPin) {
                $scope.address = true;
            } else {
                $scope.address = false;
            }

            for (var i = 0; i < $scope.marriedstatusList.length; i++) {

                if ($scope.marriedstatusList[i].parameterid == $scope.view.profMeritalStatus) {
                    $scope.profmaritalStat = $scope.marriedstatusList[i].value;
                    break;
                }
            }

            if (!$scope.profmaritalStat) {
                $scope.profmaritalStat = "Not Specified";
            }

            if (($scope.view.profMeritalStatus == 36 || $scope.view.profMeritalStatus == 38) && $scope.view.profMerriageAnniversary) {
                $scope.marriedDate = $scope.view.profMerriageAnniversary;

            } else {
                $scope.marriedDate = false;
            }

            $scope.profPan = $scope.view.profPan;


            if ($scope.view.specializationList && $scope.view.specializationList.length != 0 && $scope.view.specializationList != null) {
                $scope.specializationList = $scope.view.specializationList;
            }
            if ($scope.view.qualificationList && $scope.view.qualificationList.length != 0 && $scope.view.qualificationList != null) {
                $scope.qualificationList = $scope.view.qualificationList;
            }
            if ($scope.view.experienceList && $scope.view.experienceList.length != 0 && $scope.view.experienceList != null) {
                $scope.experienceList = $scope.view.experienceList;
            }
            if ($scope.view.acheivements && $scope.view.acheivements.length != 0 && $scope.view.acheivements != null) {
                $scope.acheivements = $scope.view.acheivements;
            }
            if ($scope.view.registeredMemNos && $scope.view.registeredMemNos.length != 0 && $scope.view.registeredMemNos != null) {
                $scope.registeredMemNos = $scope.view.registeredMemNos;
            }

            if ($scope.view.lstProfPublication && $scope.view.lstProfPublication.length != 0 && $scope.view.lstProfPublication != null) {
                $scope.lstProfPublication = $scope.view.lstProfPublication;
                for (var i = 0; i < $scope.lstProfPublication.length; i++) {
                    if ($scope.lstProfPublication[i].lstPublicationDetails[0] && $scope.lstProfPublication[i].lstPublicationDetails[0].publicationDesc) {
                        $scope.lstProfPublication[i].pubdetails = $scope.lstProfPublication[i].lstPublicationDetails[0].publicationDesc;
                    }
                }
            }

            if ($scope.view.lstProfPresentation && $scope.view.lstProfPresentation.length != 0 && $scope.view.lstProfPresentation != null) {
                $scope.lstProfPresentation = $scope.view.lstProfPresentation;
                for (var i = 0; i < $scope.lstProfPresentation.length; i++) {
                    if ($scope.lstProfPresentation[i].lstPresentationDesc[0] && $scope.lstProfPresentation[i].lstPresentationDesc[0].presentationDesc) {
                        $scope.lstProfPresentation[i].predetails = $scope.lstProfPresentation[i].lstPresentationDesc[0].presentationDesc;
                    }
                }
            }

        };



        /*----------login functionality -------------*/

        $scope.open = function() {

            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'loginmodal.html',
                controller: childloginController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
            modalInstance.result.then(function(login) {

                console.log('modal dismissed');
            }, function() {
                console.log('modal dismissed');

            });

        };


        var childloginController = function($scope, $uibModalInstance, $location, $localStorage, $sessionStorage) {



            $scope.login = {
                "username": '',
                "passWord": ''
            };
            $scope.userName = '';
            $scope.passWord = '';
            $scope.incorrect_login = false;

            if ($localStorage.loginUsername) {
                $scope.userName = $localStorage.loginUsername;
            }
            if ($localStorage.loginPassword) {
                $scope.passWord = $localStorage.loginPassword;
            }

            $scope.loginSubmit = function() {
                //$uibModalInstance.close({ my: 'data' });
                validateUsernamePassword();

            }


            $scope.cancel = function() {
                $uibModalInstance.dismiss('cancel');
            }


            validateUsernamePassword = function() {
                $scope.incorrect_login = false;
                if (ValidationFactory.hasSpecialCharacter($scope.userName)) {
                    $scope.incorrect_login = "Enter a valid username";
                    return false;
                } else {
                    $scope.login = {
                        "username": $scope.userName,
                        "passWord": $scope.passWord
                    };
                    //LoginFactory.encodePassword($scope.passWord)
                    $scope.callLoginService();
                }
            };


            $scope.callLoginService = function() {

                LoginFactory.loginService($scope.login).success(function(result, status, headers, config) {
                    //alert('success');

                    if (status = 200) {

                        USERNAME = $scope.login.username;
                        PASSWORD = $scope.login.passWord;
                        var resultHeaders = headers();
                        console.log(JSON.stringify(result));
                        console.log(JSON.stringify(status));
                        console.log(JSON.stringify(resultHeaders));
                        console.log(JSON.stringify(config));

                        USER_ID = resultHeaders.user_id;
                        X_auth_token = resultHeaders.x_auth_token;


                        $sessionStorage.loginUsername = $scope.login.username;
                        $sessionStorage.loginPassword = $scope.login.passWord;
                        $sessionStorage.logintoken = X_auth_token;
                        $sessionStorage.ProfID = USER_ID;
                        if ($scope.remember) {
                            $localStorage.loginUsername = $scope.login.username;
                            $localStorage.loginPassword = $scope.login.passWord;
                        }
                        $uibModalInstance.dismiss('cancel');

                    } else {
                        $scope.incorrect_login = "Invalid Username or Password";
                        return false;
                    }
                }).error(function(data, status, headers, config) {
                    if (status = 401) {
                        $scope.incorrect_login = "Invalid Username or Password";
                    } else {

                        $scope.incorrect_login = "Unable to connect to server . Please try again.";
                    }

                });
            };
        };
        /*----------login functionality -------------*/

        $scope.toggleAnimation = function() {
            $scope.animationsEnabled = !$scope.animationsEnabled;
        };


        /*----------alert functionality -------------*/
        callalert = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'alert.html',
                controller: childalertController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
        };
        var childalertController = function($scope, $uibModalInstance) {
                var alert = LoginFactory.getalert();
                $scope.alertHead = alert.head;
                $scope.alertText = alert.text;
                $scope.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                }

            }
            /*----------alert functionality -------------*/


    }]);



(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('ChildloginController', childloginController);

    childloginController.$inject = ['$controller'];

    function childloginController($controller) {
        var self = this;

        var baseController = $controller('ProfViewController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();
(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('childalertController', childalertController);

    childalertController.$inject = ['$controller'];

    function childalertController($controller) {
        var self = this;

        var baseController = $controller('ProfViewController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();