angular.module('profAdd', ['ngRoute', 'ngAnimate', 'ui.bootstrap.modal', 'ui.bootstrap'])
    .controller('ProfAddController', ["$scope", "$location", "$timeout", "$uibModal", "ValidationFactory", "ProfileFactory", "LoginFactory", "$window", "ErrorCode", "$localStorage", "$sessionStorage", function($scope, $location, $timeout, $uibModal, ValidationFactory, ProfileFactory, LoginFactory, $window, ErrorCode, $localStorage, $sessionStorage) {

        if (!($sessionStorage.loginUsername && $sessionStorage.loginPassword && $sessionStorage.logintoken)) {

            $location.path('/login');
        }
        
   
        
        $scope.User = $sessionStorage.loginUsername;
        X_auth_token = $sessionStorage.logintoken;
        USER_ID = $sessionStorage.ProfID;


        $scope.incorrect_membership = false;
        $scope.incorrect_education = false;
        $scope.incorrect_exp = false;
        $scope.incorrect_specalization = false;
        $scope.incorrect_publication = false;
        $scope.incorrect_submit = false;
        $scope.not_married = true;

        var file = $scope.myFile;


        $scope.profimg = "./assets/images/profile.png";


        $scope.sms = false;
        $scope.emailcheck = false;
        $scope.frstName = '';
        $scope.lstName = '';
        $scope.contact = '';
        $scope.email = '';
        $scope.gender = '';
        $scope.birthDate = '';
        $scope.marriedstatus = '';
        $scope.marrigeDate = '';
        $scope.nationality = '';
        $scope.Panno = '';
        $scope.address1 = '';
        $scope.address2 = '';
        $scope.address = '';
        $scope.state = '';
        $scope.dist = '';
        $scope.Pincode = '';
        $scope.catagory = '';
        $scope.subcatagory = '';
        $scope.town = '';
        $scope.area = '';

        $scope.statelist = [];
        $scope.nationalitylist = [];
        $scope.superDistList = [];
        $scope.DistList = [];
        $scope.twnlist = [];
        $scope.arealist = [];
        $scope.catagorylist = [];
        $scope.subcatagorylist = [];
        $scope.genderlist = [];
        $scope.marriedstatusList = [];

        $scope.membershiplist = [{
            memNo: 1,
            memType: '',
            memauth: '',
            year: '',
            id: 1
        }]
        $scope.specalizationlist = [{
            name: '',
            desc: '',
            id: 1
        }]
        $scope.publicationlist = [{
            name: '',
            desc: '',
            id: 1
        }]
        $scope.presentationlist = [{
            name: '',
            desc: '',
            id: 1
        }]
        $scope.educationlist = [{
            name: '',
            desc: '',
            institute: '',
            year: '',
            id: 1
        }]
        $scope.experiencelist = [{
            from: '',
            desc: '',
            to: '',
            id: 1
        }]
        $scope.achivementlist = [{
            name: '',
            desc: '',
            year: '',
            id: 1
        }]
        $scope.year = [{
            id: '1',
            name: '1997'
        }, {
            id: '1',
            name: '1998'
        }, {
            id: '1',
            name: '1999'
        }, {
            id: '1',
            name: '2000'
        }, {
            id: '1',
            name: '2001'
        }, {
            id: '1',
            name: '2002'
        }, {
            id: '1',
            name: '2003'
        }, {
            id: '1',
            name: '2004'
        }, {
            id: '1',
            name: '2005'
        }, {
            id: '1',
            name: '2006'
        }, {
            id: '1',
            name: '2007'
        }, {
            id: '1',
            name: '2008'
        }, {
            id: '1',
            name: '2009'
        }, {
            id: '1',
            name: '2010'
        }, {
            id: '1',
            name: '2011'
        }, {
            id: '1',
            name: '2012'
        }, {
            id: '1',
            name: '2013'
        }, {
            id: '1',
            name: '2014'
        }, {
            id: '1',
            name: '2015'
        }, {
            id: '2',
            name: '2016'
        }];

        $scope.popup1 = {
            opened: false
        };
        $scope.popup2 = {
            opened: false
        };

        $scope.popup3 = {
            opened: false
        };
        $scope.popup4 = {
            opened: false
        };




        $scope.addRegisteredMemNosTableRow = function() {
            console.log($scope.membershiplist);

            for (var i = 0; i < $scope.membershiplist.length; i++) {
                if ($scope.membershiplist[i].memNo == '' || $scope.membershiplist[i].memNo == undefined) {
                    $scope.incorrect_membership = 'Please fill the previous ones before adding';
                    return false;
                }
                if ($scope.membershiplist[i].memType == '' || $scope.membershiplist[i].memType == undefined) {
                    $scope.incorrect_membership = 'Please fill the previous ones before adding';
                    return false;
                    $scope.incorrect_membership = 'Please fill the previous ones before adding';
                    return false;
                }
                if ($scope.membershiplist[i].memauth == '' || $scope.membershiplist[i].memauth == undefined) {
                    $scope.incorrect_membership = 'Please fill the previous ones before adding';
                    return false;
                }
                if ($scope.membershiplist[i].year == '' || $scope.membershiplist[i].year == undefined) {
                    $scope.incorrect_membership = 'Please fill the previous ones before adding';
                    return false;
                }
            }

            var id = $scope.membershiplist[$scope.membershiplist.length - 1].id + 1;
            var no = id;
            $scope.membershiplist.push({
                memNo: no,
                memType: '',
                memauth: '',
                year: '',
                id: id
            });
            $scope.incorrect_membership = false;
            console.log($scope.membershiplist);

        }
        $scope.removeRegisteredMemNosTableRow = function(id) {
            if ($scope.membershiplist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.membershiplist.length; i++) {
                if ($scope.membershiplist[i].id == id) {
                    $scope.membershiplist.splice(i, 1);
                    console.log($scope.membershiplist);
                    break;
                }
            }
        }




        $scope.addQualificationTableRow = function() {
            console.log($scope.educationlist);

            for (var i = 0; i < $scope.educationlist.length; i++) {
                if ($scope.educationlist[i].name == '' || $scope.educationlist[i].name == undefined) {
                    $scope.incorrect_education = 'Please fill the previous ones before adding';
                    return false;
                }
                /*  if($scope.educationlist[i].desc==''||$scope.educationlist[i].desc==undefined){
                      $scope.incorrect_education = 'Please fill the previous ones before adding'; 
                      return false;$scope.incorrect_education = 'Please fill the previous ones before adding'; 
                      return false;
                  }*/
                if ($scope.educationlist[i].institute == '' || $scope.educationlist[i].institute == undefined) {
                    $scope.incorrect_education = 'Please fill the previous ones before adding';
                    return false;
                }
                if ($scope.educationlist[i].year == '' || $scope.educationlist[i].year == undefined) {
                    $scope.incorrect_education = 'Please fill the previous ones before adding';
                    return false;
                }
            }

            var id = $scope.educationlist[$scope.educationlist.length - 1].id + 1;
            $scope.educationlist.push({
                name: '',
                desc: '',
                institute: '',
                year: '',
                id: id
            });
            $scope.incorrect_education = false;
            console.log($scope.educationlist);

        }

        $scope.removeQualificationTableRow = function(id) {
            if ($scope.educationlist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.educationlist.length; i++) {
                if ($scope.educationlist[i].id == id) {
                    $scope.educationlist.splice(i, 1);
                    console.log($scope.educationlist);
                    break;
                }
            }
        }




        $scope.addExperienceTableRow = function() {
            console.log($scope.experiencelist);

            for (var i = 0; i < $scope.experiencelist.length; i++) {
                if ($scope.experiencelist[i].from == '' || $scope.experiencelist[i].from == undefined) {
                    $scope.incorrect_exp = 'Please fill the previous ones before adding';
                    return false;
                }
                /* if($scope.experiencelist[i].desc==''||$scope.experiencelist[i].desc==undefined){
                     $scope.incorrect_exp = 'Please fill the previous ones before adding'; 
                     return false;$scope.incorrect_exp = 'Please fill the previous ones before adding'; 
                     return false;
                 }*/
                if ($scope.experiencelist[i].to == '' || $scope.experiencelist[i].to == undefined) {
                    $scope.incorrect_exp = 'Please fill the previous ones before adding';
                    return false;
                }

            }

            var id = $scope.experiencelist[$scope.experiencelist.length - 1].id + 1;
            $scope.experiencelist.push({
                name: '',
                desc: '',
                institute: '',
                year: '',
                id: id
            });
            $scope.incorrect_exp = false;
            console.log($scope.experiencelist);

        }

        $scope.removeExperienceTableRow = function(id) {
            if ($scope.experiencelist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.experiencelist.length; i++) {
                if ($scope.experiencelist[i].id == id) {
                    $scope.experiencelist.splice(i, 1);
                    console.log($scope.experiencelist);
                    break;
                }
            }
        }




        $scope.addSpecializationTableRow = function() {
            console.log($scope.specalizationlist);

            for (var i = 0; i < $scope.specalizationlist.length; i++) {
                if ($scope.specalizationlist[i].name == '' || $scope.specalizationlist[i].name == undefined) {
                    $scope.incorrect_specalization = 'Please fill the previous ones before adding';
                    return false;
                }
                /*   if($scope.specalizationlist[i].desc==''||$scope.specalizationlist[i].desc==undefined){
                       $scope.incorrect_specalization = 'Please fill the previous ones before adding'; 
                       return false;
                   }*/

            }

            var id = $scope.specalizationlist[$scope.specalizationlist.length - 1].id + 1;
            $scope.specalizationlist.push({
                name: '',
                desc: '',
                id: id
            });
            $scope.incorrect_specalization = false;
            console.log($scope.specalizationlist);

        }

        $scope.removeSpecializationTableRow = function(id) {
            if ($scope.specalizationlist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.specalizationlist.length; i++) {
                if ($scope.specalizationlist[i].id == id) {
                    $scope.specalizationlist.splice(i, 1);
                    console.log($scope.specalizationlist);
                    break;
                }
            }
        }



        $scope.addPublicationTableRow = function() {
            console.log($scope.publicationlist);

            for (var i = 0; i < $scope.publicationlist.length; i++) {
                if ($scope.publicationlist[i].name == '' || $scope.publicationlist[i].name == undefined) {
                    $scope.incorrect_publication = 'Please fill the previous ones before adding';
                    return false;
                }
                if ($scope.publicationlist[i].desc == '' || $scope.publicationlist[i].desc == undefined) {
                    $scope.incorrect_publication = 'Please fill the previous ones before adding';
                    return false;
                }

            }

            var id = $scope.publicationlist[$scope.publicationlist.length - 1].id + 1;
            $scope.publicationlist.push({
                name: '',
                desc: '',
                id: id
            });
            $scope.incorrect_publication = false;
            console.log($scope.publicationlist);

        }

        $scope.removePublicationTableRow = function(id) {
            if ($scope.publicationlist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.publicationlist.length; i++) {
                if ($scope.publicationlist[i].id == id) {
                    $scope.publicationlist.splice(i, 1);
                    console.log($scope.publicationlist);
                    break;
                }
            }
        }



        $scope.addPresentationTableRow = function() {
            console.log($scope.presentationlist);

            for (var i = 0; i < $scope.presentationlist.length; i++) {
                if ($scope.presentationlist[i].name == '' || $scope.presentationlist[i].name == undefined) {
                    $scope.incorrect_presentation = 'Please fill the previous ones before adding';
                    return false;
                }
                if ($scope.presentationlist[i].desc == '' || $scope.presentationlist[i].desc == undefined) {
                    $scope.incorrect_presentation = 'Please fill the previous ones before adding';
                    return false;
                }

            }

            var id = $scope.presentationlist[$scope.presentationlist.length - 1].id + 1;
            $scope.presentationlist.push({
                name: '',
                desc: '',
                id: id
            });
            $scope.incorrect_presentation = false;
            console.log($scope.presentationlist);

        }

        $scope.removePresentationTableRow = function(id) {
            if ($scope.presentationlist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.presentationlist.length; i++) {
                if ($scope.presentationlist[i].id == id) {
                    $scope.presentationlist.splice(i, 1);
                    console.log($scope.presentationlist);
                    break;
                }
            }
        }


        $scope.addAcheivementsTableRow = function() {
            console.log($scope.achivementlist);

            for (var i = 0; i < $scope.achivementlist.length; i++) {
                if ($scope.achivementlist[i].name == '' || $scope.achivementlist[i].name == undefined) {
                    $scope.incorrect_achivement = 'Please fill the previous ones before adding';
                    return false;
                }
                /*  if($scope.achivementlist[i].desc==''||$scope.achivementlist[i].desc==undefined){
                      $scope.incorrect_achivement = 'Please fill the previous ones before adding'; 
                      return false;
                  }*/
                if ($scope.achivementlist[i].year == '' || $scope.achivementlist[i].year == undefined) {
                    $scope.incorrect_achivement = 'Please fill the previous ones before adding';
                    return false;
                }

            }

            var id = $scope.achivementlist[$scope.achivementlist.length - 1].id + 1;
            $scope.achivementlist.push({
                name: '',
                desc: '',
                year: '',
                id: id
            });
            $scope.incorrect_achivement = false;
            console.log($scope.achivementlist);

        }

        $scope.removeAcheivementsTableRow = function(id) {
            if ($scope.achivementlist.length == 1) {
                return false;
            }

            for (var i = 0; i < $scope.achivementlist.length; i++) {
                if ($scope.achivementlist[i].id == id) {
                    $scope.achivementlist.splice(i, 1);
                    console.log($scope.achivementlist);
                    break;
                }
            }
        }




        callgetUserdetails = function() {

            ProfileFactory.getUserdetails().success(function(result, status, headers, config) {
                
                if (result.responseCode == 000 && result.responseObj) {

                    $scope.frstName = result.responseObj.userFirstName;
                    $scope.lstName = result.responseObj.userLastName;
                    $scope.contact = result.responseObj.userContact;
                    $scope.email = result.responseObj.email;
                    $scope.userName = result.responseObj.userName;
                    callgetAddprofdetails();
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }

            }).error(function(data, status, headers, config) {
                if (status == 401) {
                    $scope.open();
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                //$scope.username_check = false;
                //$scope.username_check_failed = false;
                //$scope.incorrect_username = 'user name not verified';
            });
        };

        callgetAddprofdetails = function() {

            ProfileFactory.getaddProfdetails().success(function(result, status, headers, config) {

                if (result.responseObj.genders && result.responseObj.genders.length != 0) {
                    $scope.genderlist = result.responseObj.genders;
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }

                if (result.responseObj.maritalStatus && result.responseObj.maritalStatus.length != 0) {
                    $scope.marriedstatusList = result.responseObj.maritalStatus;
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                if (result.responseObj.locations && result.responseObj.locations.length != 0) {
                    $scope.nationalitylist = result.responseObj.locations;
                    //$scope.statelist = $scope.nationalitylist[0].childLocations;
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                if (result.responseObj.categories && result.responseObj.categories.length != 0) {
                    $scope.catagorylist = result.responseObj.categories;
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }



            }).error(function(data, status, headers, config) {
                if (status == 401) {
                    $scope.open();
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                //$scope.username_check = false;
                //$scope.username_check_failed = false;
                //$scope.incorrect_username = 'user name not verified';
            });

        };

        $scope.getDIST = function() {

            $scope.dist = '';
            $scope.DistList = [];
            $scope.town = '';
            $scope.twnlist = [];
            $scope.area = '';
            $scope.arealist = [];

            ProfileFactory.getDistdetails($scope.state).success(function(result, status, headers, config) {
                //alert('success');
                if (result.responseCode == 000 && result.responseObj && result.responseObj.length != 0) {
                    $scope.DistList = result.responseObj;
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }


            }).error(function(data, status, headers, config) {
                if (status == 401) {
                    $scope.open();
                } else {
                    LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                    callalert();
                }
                //$scope.username_check = false;
                //$scope.username_check_failed = false;
                //$scope.incorrect_username = 'user name not verified';
            });

        }

         $scope.getTWN = function() {

            $scope.town = '';
            $scope.twnlist = [];
            $scope.area = '';
            $scope.arealist = [];
            var length = $scope.DistList.length;
            for (var i = 0; i < length; i++) {
                if ($scope.DistList[i].id == $scope.dist) {
                    console.log($scope.DistList[i].childs.length);
                    $scope.twnlist = $scope.DistList[i].childs;
                    break;
                }
            }
        }

        $scope.getArea = function() {
            $scope.area = '';
            $scope.arealist = [];
            var length = $scope.twnlist.length;
            for (var i = 0; i < length; i++) {
                if ($scope.twnlist[i].id == $scope.town) {
                    console.log($scope.twnlist[i].childs.length);
                    $scope.arealist = $scope.twnlist[i].childs;
                    break;
                }
            }
        }
         $scope.getstate = function() {
            $scope.statelist = [];
            $scope.state = '';
            $scope.area = '';
            $scope.arealist = [];
            $scope.town = '';
            $scope.twnlist = [];
            $scope.dist = '';
            $scope.DistList = [];

            for (var i = 0; i < $scope.nationalitylist.length; i++) {
                if ($scope.nationalitylist[i].id == $scope.nationality) {
                    console.log($scope.nationalitylist[i].childs.length);
                    $scope.statelist = $scope.nationalitylist[i].childs;
                    break;
                }
            }

        }

        $scope.getSubcatgories = function() {
            for (var i = 0; i < $scope.catagorylist.length; i++) {
                if ($scope.catagorylist[i].catId == $scope.catagory) {
                    $scope.subcatagorylist = $scope.catagorylist[i].subCategoryList;
                    break;
                }
            }

        }
        $scope.getmarriedStatus = function() {
            if ($scope.marriedstatus == 36 || $scope.marriedstatus == 38) {
                $scope.not_married = false;
            } else {
                $scope.marrigeDate = '';
                $scope.not_married = true;
            }
        }
        callgetUserdetails();




        $scope.saveProfile = function() {
            var params = {}

            params.recordId = USER_ID;
            params.profGender = parseInt($scope.gender);
            params.profFirstName = $scope.frstName;
            params.profLastName = $scope.lstName;
            params.profNationality = $scope.nationality;
            params.profPan = $scope.Panno;
            if($scope.birthDate){
            params.profDob = ProfileFactory.changedate($scope.birthDate);
            }
            params.profMeritalStatus = $scope.marriedstatus;
            if ($scope.marriedstatus == 36 || $scope.marriedstatus == 38) {
                params.profMerriageAnniversary = ProfileFactory.changedate($scope.marrigeDate);
            } else {
                console.log('nothing');
            }
            if (!$scope.emailcheck) {
                params.emailStatus = "false";
            } else {
                params.emailStatus = "true";
            }

            if (!$scope.sms) {
                params.dndActivatedFlag = 0;
            } else {
                params.dndActivatedFlag = 1;
            }

            var contactList = [];
            var contact = {};
            contact.contactPhone = $scope.contact;
            contact.contactEmail = $scope.email;
            contact.activeStatus = 1;
            contactList.push(contact);
            params.contactList = contactList;

            var addressList = [];
            var address = {};
            address.line1 = $scope.address1;
            address.line2 = $scope.address2;
            address.pinCode = $scope.Pincode;
            address.locationId = parseInt($scope.area);
            address.activeStatus = 1;
            addressList.push(address);
            params.addressList = addressList;

            var specializationList = [];
            for (var i = 0; i < $scope.specalizationlist.length; i++) {
                if ($scope.specalizationlist[i].name) {
                    specializationList.push({
                        profSpecName: $scope.specalizationlist[i].name,
                        profSpecDesc: $scope.specalizationlist[i].desc,
                        activeStatus: 1
                    })
                }
            };
            params.specializationList = specializationList;

            var qualificationList = [];
            for (var i = 0; i < $scope.educationlist.length; i++) {
                if ($scope.educationlist[i].name && $scope.educationlist[i].institute && $scope.educationlist[i].year) {
                    qualificationList.push({
                        profAcdmcName: $scope.educationlist[i].name,
                        profAcdmcDesc: $scope.educationlist[i].desc,
                        profAcdmcUniversity: $scope.educationlist[i].institute,
                        profAcdmcPassYear: $scope.educationlist[i].year,
                        activeStatus: 1
                    })
                }
            };
            params.qualificationList = qualificationList;

            var experienceList = [];
            for (var i = 0; i < $scope.experiencelist.length; i++) {
                if ($scope.experiencelist[i].from && $scope.experiencelist[i].to) {
                    experienceList.push({
                        profExpBeginDt: ProfileFactory.changedate($scope.experiencelist[i].from),
                        profExpEndDt: ProfileFactory.changedate($scope.experiencelist[i].to),
                        profExpDesc: $scope.experiencelist[i].desc,
                        activeStatus: 1
                    })
                }
            }
            params.experienceList = experienceList;


            var acheivements = [];
            for (var i = 0; i < $scope.achivementlist.length; i++) {
                if ($scope.achivementlist[i].name && $scope.achivementlist[i].year) {
                    acheivements.push({
                        profAchvName: $scope.achivementlist[i].name,
                        profAchvDesc: $scope.achivementlist[i].desc,
                        profAchvYear: $scope.achivementlist[i].year,
                        activeStatus: 1
                    })
                }
            }
            params.acheivements = acheivements;

            var registeredMemNos = [];

            for (var i = 0; i < $scope.membershiplist.length; i++) {
                if ($scope.membershiplist[i].memNo && $scope.membershiplist[i].memType && $scope.membershiplist[i].memauth && $scope.membershiplist[i].year) {
                    registeredMemNos.push({
                        regMemType: $scope.membershiplist[i].memType,
                        regAuth: $scope.membershiplist[i].memauth,
                        regYear: $scope.membershiplist[i].year,
                        activeStatus: 1
                    })
                }
            };
            params.registeredMemNos = registeredMemNos;

            var lstSubCategoryId = $scope.subcatagory;
            for (var i = 0; i < lstSubCategoryId.length; i++) {
                lstSubCategoryId[i] = parseInt(lstSubCategoryId[i]);
            }
            params.lstSubCategoryId = lstSubCategoryId;

            var lstProfPublication = [];
            for (var i = 0; i < $scope.publicationlist.length; i++) {
                if ($scope.publicationlist[i].name && $scope.publicationlist[i].desc) {
                    var pubdetails = [];
                    pubdetails.push({
                        'publicationDesc': $scope.publicationlist[i].desc
                    });
                    lstProfPublication.push({
                        profPublicationName: $scope.publicationlist[i].name,
                        lstPublicationDetails: pubdetails,
                        activeStatus: 1
                    })
                }
            };
            params.lstProfPublication = lstProfPublication;

            var lstProfPresentation = [];

            for (var i = 0; i < $scope.presentationlist.length; i++) {
                if ($scope.presentationlist[i].name && $scope.presentationlist[i].desc) {
                    var predetails = [];
                    predetails.push({
                        'presentationDesc': $scope.presentationlist[i].desc
                    });
                    lstProfPresentation.push({
                        profPresentationName: $scope.presentationlist[i].name,
                        lstPresentationDesc: predetails,
                        activeStatus: 1
                    })
                }
            };
            params.lstProfPresentation = lstProfPresentation;

            console.log(JSON.stringify(params));

            if (!params.profFirstName || params.profFirstName == '' || params.profFirstName == undefined || ValidationFactory.isAplhabetic(params.profFirstName)) {
                LoginFactory.setalert('Please Provide Your correct firstname', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your correct firstname';
                return false;
            } else if (!params.profLastName || params.profLastName == '' || params.profLastName == undefined || ValidationFactory.isAplhabetic(params.profLastName)) {
                LoginFactory.setalert('Please Provide Your correct Lastname', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your correct Lastname';
                return false;
            } else if ((!params.profNationality || params.profNationality == '' || params.profNationality == undefined)) {
                LoginFactory.setalert('Please Provide Your Nationality', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your Nationality';
                return false;
            } else if ((!params.addressList[0].locationId || params.addressList[0].locationId == '' || params.addressList[0].locationId == undefined)) {
                LoginFactory.setalert('Please Provide Your state,district,town & area', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your state,district,town & area';
                return false;
            } else if ((!params.addressList[0].line1 || params.addressList[0].line1 == '' || params.addressList[0].line1 == undefined) && (!params.addressList[0].line2 || params.addressList[0].line2 == '' || params.addressList[0].line2 == undefined)) {
                LoginFactory.setalert('Please Provide Your address', 'Failure');
                callalert();
                // $scope.incorrect_submit = 'Please Provide Your address';
                return false;
            } else if ((!params.addressList[0].pinCode || params.addressList[0].pinCode == '' || params.addressList[0].pinCode == undefined) || params.addressList[0].pinCode.length != 6 || ValidationFactory.notaNumer(params.addressList[0].pinCode)) {
                LoginFactory.setalert('Please Provide Your correct pincode', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your correct pincode';
                return false;
            } else if ((!params.contactList[0].contactPhone || params.contactList[0].contactPhone == '' || params.contactList[0].contactPhone == undefined || params.contactList[0].contactPhone.length != 10 || ValidationFactory.notaNumer(params.contactList[0].contactPhone))) {
                LoginFactory.setalert('Please Provide a correct phone number', 'Failure');
                callalert();
                // $scope.incorrect_submit = 'Please Provide a correct phone number';
                return false;
            } else if ((!params.contactList[0].contactEmail || params.contactList[0].contactEmail == '' || params.contactList[0].contactEmail == undefined || ValidationFactory.notemail(params.contactList[0].contactEmail))) {
                LoginFactory.setalert('Please Provide a correct email ID', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide a correct email ID';
                return false;
            } else if (ValidationFactory.notpan(params.profPan)) {
                LoginFactory.setalert('Please Provide a correct PAN no.', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide a correct PAN no.';
                return false;
            } else if ((!params.profDob || params.profDob == '' || params.profDob == undefined)) {
                LoginFactory.setalert('Please Provide Your Date of birth', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your Date of birth';
                return false;
            } else if ((!params.profMeritalStatus || params.profMeritalStatus == '' || params.profMeritalStatus == undefined)) {
                LoginFactory.setalert('Please Provide Your Merital status', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your Merital status';
                return false;
            } else if ((!params.profGender || params.profGender == '' || params.profGender == undefined)) {
                LoginFactory.setalert('Please Provide Your Gender', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your Gender';
                return false;
            } else if ((!params.lstSubCategoryId || params.lstSubCategoryId == '' || params.lstSubCategoryId == undefined || params.lstSubCategoryId.length == 0)) {
                LoginFactory.setalert('Please Provide Your professional catagory and subcatagories', 'Failure');
                callalert();
                //$scope.incorrect_submit = 'Please Provide Your professional catagory and subcatagories';
                return false;
            } else {
                ProfileFactory.saveProfile(params, $scope.User).success(function(result, status, headers, config) {
                    if (result.responseCode == '000') {
                        $scope.incorrect_membership = false;
                        $scope.incorrect_education = false;
                        $scope.incorrect_exp = false;
                        $scope.incorrect_specalization = false;
                        $scope.incorrect_publication = false;
                        $scope.incorrect_submit = false;
                        //alert('success');
                        $location.path('/viewprofile');
                    }
                    else {

                        LoginFactory.setalert(result.responseMsg, 'Failure');
                        callalert();
                    }
                }).error(function(data, status, headers, config) {

                    if (status == 401) {

                        $scope.open();
                    } else {

                        LoginFactory.setalert('Unable to connect to server . Please try again.', 'Failure');
                        callalert();
                    }
                });

            }


        }




        /*----------------for date---------------*/

        $scope.today = function() {
            $scope.dt = new Date();
        };
        $scope.today();

        $scope.clear = function() {
            $scope.dt = null;
        };

        $scope.minDate = new Date(1950, 1, 01);



        $scope.maxDate = new Date();;

        $scope.open1 = function() {
            $scope.popup1.opened = true;
        };

        $scope.open2 = function() {
            $scope.popup2.opened = true;
        };

        $scope.open3 = function() {
            $scope.popup3.opened = true;
        };

        $scope.open4 = function() {
            $scope.popup4.opened = true;
        };
        $scope.setDate = function(year, month, day) {
            $scope.dt = new Date(year, month, day);
        };

        $scope.dateOptions = {
            formatYear: 'yy',
            startingDay: 1
        };


        /*----------------for date---------------*/




        /*----------login functionality -------------*/

        $scope.open = function() {

            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'loginmodal.html',
                controller: childloginController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
            modalInstance.result.then(function(login) {

                console.log('modal dismissed');
            }, function() {
                console.log('modal dismissed');

            });

        };


        var childloginController = function($scope, $uibModalInstance, $location, $localStorage, $sessionStorage) {



            $scope.login = {
                "username": '',
                "passWord": ''
            };
            $scope.userName = '';
            $scope.passWord = '';
            $scope.incorrect_login = false;

            if ($localStorage.loginUsername) {
                $scope.userName = $localStorage.loginUsername;
            }
            if ($localStorage.loginPassword) {
                $scope.passWord = $localStorage.loginPassword;
            }

            $scope.loginSubmit = function() {
                //$uibModalInstance.close({ my: 'data' });
                validateUsernamePassword();

            }


            $scope.cancel = function() {
                $uibModalInstance.dismiss('cancel');
            }


            validateUsernamePassword = function() {
                $scope.incorrect_login = false;
                if (ValidationFactory.hasSpecialCharacter($scope.userName)) {
                    $scope.incorrect_login = "Enter a valid username";
                    return false;
                } else {
                    $scope.login = {
                        "username": $scope.userName,
                        "passWord": $scope.passWord
                    };
                    //LoginFactory.encodePassword($scope.passWord)
                    $scope.callLoginService();
                }
            };


            $scope.callLoginService = function() {

                LoginFactory.loginService($scope.login).success(function(result, status, headers, config) {
                    //alert('success');

                    if (status = 200) {

                        USERNAME = $scope.login.username;
                        PASSWORD = $scope.login.passWord;
                        var resultHeaders = headers();
                        console.log(JSON.stringify(result));
                        console.log(JSON.stringify(status));
                        console.log(JSON.stringify(resultHeaders));
                        console.log(JSON.stringify(config));

                        USER_ID = resultHeaders.user_id;
                        X_auth_token = resultHeaders.x_auth_token;


                        $sessionStorage.loginUsername = $scope.login.username;
                        $sessionStorage.loginPassword = $scope.login.passWord;
                        $sessionStorage.logintoken = X_auth_token;
                        $sessionStorage.ProfID = USER_ID;
                        if ($scope.remember) {
                            $localStorage.loginUsername = $scope.login.username;
                            $localStorage.loginPassword = $scope.login.passWord;
                        }
                        $uibModalInstance.dismiss('cancel');

                    } else {
                        $scope.incorrect_login = "Invalid Username or Password";
                        return false;
                    }
                }).error(function(data, status, headers, config) {
                    if (status = 401) {
                        $scope.incorrect_login = "Invalid Username or Password";
                    } else {

                        $scope.incorrect_login = "Unable to connect to server . Please try again.";
                    }

                });
            };
        };
        /*----------login functionality -------------*/

        $scope.toggleAnimation = function() {
            $scope.animationsEnabled = !$scope.animationsEnabled;
        };


        /*----------alert functionality -------------*/
        callalert = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'alert.html',
                controller: childalertController,
                size: '',
                backdrop: 'static',
                resolve: {
                    login: function() {
                        return $scope.login;
                    }
                }
            });
        };
        var childalertController = function($scope, $uibModalInstance) {
                var alert = LoginFactory.getalert();
                $scope.alertHead = alert.head;
                $scope.alertText = alert.text;
                $scope.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                }

            }
            /*----------alert functionality -------------*/




    }])

.service('fileUpload', ['$http', function($http) {
    this.uploadFileToUrl = function(file) {
        var fd = new FormData();
        fd.append('file', file);
        var uploadUrl = CONTEXT_URL + Upload_BASE_URL;
        $http.post(uploadUrl, {
                transformRequest: angular.identity,
                data: fd,
                headers: {
                    'X_Auth_Token': X_auth_token,
                    'Content-Type': undefined,
                    'data-Type': 'text',
                    cache: false,
                }
            })
            .success(function() {})
            .error(function() {});
    }
}])




.directive('fileModel', ['$parse', function($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;

            element.bind('change', function() {
                scope.$apply(function() {
                    var arrayBufferView = new Uint8Array(element[0].files[0]);
                    var blob = new Blob([arrayBufferView], {
                        type: "image/jpeg"
                    });
                    var urlCreator = window.URL || window.webkitURL;
                    var imageUrl = urlCreator.createObjectURL(blob);
                    scope.profimg = imageUrl;
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('ChildloginController', childloginController);

    childloginController.$inject = ['$controller'];

    function childloginController($controller) {
        var self = this;

        var baseController = $controller('ProfAddController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();
(function() {
    'use strict';

    angular
        .module('app', ['ngAnimate', 'ui.bootstrap'])
        .controller('childalertController', childalertController);

    childalertController.$inject = ['$controller'];

    function childalertController($controller) {
        var self = this;

        var baseController = $controller('ProfAddController', {
            self: self
        });

        angular.extend(this, baseController);
    }
})();