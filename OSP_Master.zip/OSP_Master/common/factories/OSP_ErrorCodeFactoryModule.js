angular.module('errorFactoryModule', ['ngRoute','ui.bootstrap'])
        .factory('ErrorCode',["$log", function($log) { 

/*----------SERVER SIDE ERROR CODES AND ERROR MESSAGES----------*/ 
    
    var NO_MAPPING_FOUND = 'An error has occured. Please try again';            
    var G000_MSG = "Task completed successfully";
    
            
    /*------GENERIC ERROR MESSAGES---------------*/        
            
    var G204_MSG = "Unable to retrieve information from server";            
    var G400_MSG = "Unable to retrieve information from server";             
    var G412_MSG = "Unable to retrieve information from server";       
    var G500_MSG = "Unable to retrieve information from server";
    var G633_MSG = "Unable to retrieve information from server";        
    var G504_MSG = "Server connection has timed out";
    var G403_MSG = "Server access has been denied";
    var G_DEFAULT_MSG = "Unable to connect to the server";
    

    /*------LOGIN ERROR MESSAGES---------------*/        
    
    var L600_MSG = "Please enter your valid username/password";    
    var L601_MSG = "Please enter a username";  
    var L602_MSG = "Please enter a valid username"; 
    var L603_MSG = "Please enter a password"; 
   
            

            

        
    function getALErrorMsgByErrorCode(code, mod, scenario){
        $log.debug("calling getALErrorMsgByErrorCode: code-"+code+"  module- "+mod+"  scenario- "+scenario);
        var errorMsgFound = false;
        var errorMsg = '';
        var checkScenario;
        if(!scenario){            
            checkScenario = 'null';
        }
        else{
            checkScenario = scenario;
        }
        
        var errorAL = {"divisions":[{"module": "service",
                     "errorMap": [
                                    {"errorCode": "204", "errorMsg": G204_MSG, "errorScenario": "null"},
                                    {"errorCode": "400", "errorMsg": G400_MSG, "errorScenario": "null"},                                    
                                    {"errorCode": "412", "errorMsg": G412_MSG, "errorScenario": "null"},
                                    {"errorCode": "500", "errorMsg": G500_MSG, "errorScenario": "null"},
                                    {"errorCode": "633", "errorMsg": G633_MSG, "errorScenario": "null"},
                                    {"errorCode": "403", "errorMsg": G403_MSG, "errorScenario": "null"},
                                    {"errorCode": "504", "errorMsg": G504_MSG, "errorScenario": "null"}]},
                    {"module": "login",
                     "errorMap": [  
                                    {"errorCode": "204", "errorMsg": G204_MSG, "errorScenario": "null"},
                                    {"errorCode": "400", "errorMsg": G400_MSG, "errorScenario": "null"},                                    
                                    {"errorCode": "412", "errorMsg": G412_MSG, "errorScenario": "null"},
                                    {"errorCode": "500", "errorMsg": G500_MSG, "errorScenario": "null"},
                                    {"errorCode": "633", "errorMsg": G633_MSG, "errorScenario": "null"},
                                    {"errorCode": "600", "errorMsg": L600_MSG, "errorScenario": "null"}]}
                                   ]}
 
                var modLen = errorAL.divisions.length;        
               for(var i=0; i<modLen; i++){                   
                  if(errorAL.divisions[i].module == mod){ // matching module
                      $log.debug("module matched");
                      var totalErrorCode = errorAL.divisions[i].errorMap.length;                     
                        for (var a=0; a<totalErrorCode; a++){ //matching error code 
                            
                            if(errorAL.divisions[i].errorMap[a].errorCode == code ){ //error code matching found
                                $log.debug("code matched");
                                if(errorAL.divisions[i].errorMap[a].errorScenario){ //scenario provided                                    
                                    if(errorAL.divisions[i].errorMap[a].errorScenario == checkScenario){ //scenario matched
                                        $log.debug("scenario matched");
                                        errorMsgFound = true;
                                        errorMsg = errorAL.divisions[i].errorMap[a].errorMsg;
                                        break;
                                    }
                                    else{  
                                        $log.debug("scenario not matched");          //no such scenario found
                                    }
                                }                                
                                else{
                                     $log.debug("scenario not provided"); //scenario not provided
                                     errorMsgFound = true;
                                     errorMsg = errorAL.divisions[i].errorMap[a].errorMsg;
                                     break;
                                }
                            }                           
                        }
                      if(!errorMsgFound){   //no such error code found 
                          $log.debug("no such error code found");
                            if(mod == "service"){
                                    errorMsg = G_DEFAULT_MSG;
                                    break;
                                }
                                else{
                                    errorMsg = NO_MAPPING_FOUND;
                                    break;
                                }
                      }
                  }                   
               }
            return errorMsg;
    }
        
/*----------CLIENT SIDE ERROR CODES AND ERROR MESSAGES----------*/    
        function getPLErrorMsgByErrorCode(code){ 
            $log.debug("calling getPLErrorMsgByErrorCode: code- "+code);
          var errorPL = [{"errorCode": "ISPL101", "errorMsg": L601_MSG},
                         {"errorCode": "ISPL102", "errorMsg": L602_MSG},
                         {"errorCode": "ISPL103", "errorMsg": L603_MSG}];
                 
                 for(var i=0;i<errorPL.length;i++){
                  if(errorPL[i].errorCode == code){
                      return errorPL[i].errorMsg;
                    }
                  }
                return G_NO_MAPPING;

                 
                 }
                              
        return{ getALErrorMsgByErrorCode: getALErrorMsgByErrorCode,
                getPLErrorMsgByErrorCode: getPLErrorMsgByErrorCode
              }
        
        
        
        
        
        
        }])