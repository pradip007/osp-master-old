angular.module('validationFactory', ['ngRoute','ui.bootstrap'])
        .factory('ValidationFactory',[function() {		
		
        var userNameRegex = /^[a-zA-Z0-9]*$/;
			// console.log(regex.test(id));
			// if(id.match(regex))
			
				
		
		function validateId(inputItem, inputType){
			var validateObj = {
								"isInputDefined": false,
								"isInputAString": false,
								"isPassingFormat": false
							  };
			var regex = "";
			
			if(inputItem && inputType)
			{
				validateObj.isInputDefined = true;
				if(angular.isString(inputItem) && angular.isString(inputType))
				{						
					validateObj.isInputAString = true;
					switch(inputType){
                        case "userName":	regex = userNameRegex;										
                                    break;
						
						default:	console.log("Sorry no match for "+inputType);
							
					}
					
					if(regex)
					{							
						validateObj.isPassingFormat = testId(inputItem, regex);						
					}
				}				
			}						
			return validateObj;
		}                     
		
		function hasSpecialCharacter(text){
		

		  var regex = /^[a-zA-Z0-9]*$/; // Allows only characters and digits
            if(!angular.isString(text)){
              text=text.toString();
             }
			if(text.match(regex)) 
			{
				// Has special character                                  
				return false;
			}
			else{

				return true;

			}		         

		};
									  
	/*--------Writen By Pradip method to detect any whitespace in the given input used in the  whole Putaway------------*/     
									  
		function detetcWhiteSpace(text){ 
         if(text){ 
             if(!angular.isString(text)){
              text=text.toString();
             }
                var str = text.trim(); 
                var regex = " ";                          
               if(text.match(regex)) 
                {
                    // Has white space                                
                    return true;
                }
                else{

                    return false;

                }		         
         }
        return true;
									  
		};  
					  
									  
	   /*--------Writen By Pradip method to validate if given Input is a number or not Used in Putaway ------------*/                                   
		function notaNumer(text){
        if(text){    
              text=text.toString();
                console.log("notaNumer :string: "+text);
                  var regex = /^[0-9]*$/; // Allows only digits                        
                    if(text.match(regex)) 
                    {                                  
                        return false;
                    }
                    else{
                        return true;
                    }		         
        }
         return true;   
		};   
            
            
        function notemail(text){
        if(text){    
              text=text.toString();
                console.log("notaNumer :string: "+text);
                  var regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/; // Allows only email                        
                    if(text.match(regex)) 
                    {                                  
                        return false;
                    }
                    else{
                        return true;
                    }		         
        }
         return true;   
		};       

            
            function notpan(text){
        if(text){    
              text=text.toString();
                console.log("notaNumer :string: "+text);
                  var regex = /^[A-Za-z]{5}\d{4}[A-Za-z]{1}$/; // Allows only email                        
                    if(text.match(regex)) 
                    {                                  
                        return false;
                    }
                    else{
                        return true;
                    }		         
        }
         return true;   
		};    
            
        function hasANumer(text){
        if(!angular.isString(text)){    
              text=text.toString();
                console.log("notaNumer :string: "+text);
                  var regex = /^[a-zA-Z]*$/; // Allows only digits                        
                    if(text.match(regex)) 
                    {                                  
                        return true;
                    }
                    else{
                        return false;
                    }		         
        }
         return true;   
		};    
        
         function isAplhabetic(text){
		

		  var regex = /^[a-zA-Z]*$/; // Allows only characters and digits
            if(!angular.isString(text)){
              text=text.toString();
             }
			if(text.match(regex)) 
			{
				// Has special character                                  
				return false;
			}
			else{

				return true;

			}		         

		};    
            
        
 		return{
 		 	hasSpecialCharacter: hasSpecialCharacter,
            notaNumer:notaNumer,
            hasANumer:hasANumer,
            detetcWhiteSpace:detetcWhiteSpace,
            validateId: validateId,
            isAplhabetic:isAplhabetic,
            notemail:notemail,
            notpan:notpan
		}    
 	
 		 
    }])
      