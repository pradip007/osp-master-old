angular.module('globalFactory', ['ngRoute','ui.bootstrap'])
        .factory('GlobalFactory',["$http", function($http) {
 	
        
 	
}])
      